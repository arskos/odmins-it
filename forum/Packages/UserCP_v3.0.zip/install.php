<?php

function doSettings($addSettings, $smf2 = true)
{
   global $smcFunc, $db_prefix;

   $update = array();

   foreach ($addSettings as $variable => $s)
   {
      list ($value, $overwrite) = $s;

      $result = $smcFunc['db_query']('', '
         SELECT value
         FROM {db_prefix}settings
         WHERE variable = {string:variable}',
         array(
            'variable' => $variable,
         )
      );

      if ($smcFunc['db_num_rows']($result) == 0 || $overwrite == false)
         $update[$variable] = $value;
   }

   if (!empty($update))
      updateSettings($update);
}

// USAGE
$addSettings = array(
   'usercp_enable' => array(1, false),
    'usercp_enablecontactadmin' => array(1, false),
    'usercp_switchview' => array(1, false),
    'usecp_showadminid' => array(1, false),
    'usercp_contact_email' => array('Your Email Here', false),
    'usercp_usepm' => array(0, false),
    'usercp_adminid' => array('1', false),
    'usercp_enable_account' => array(1, false),
    'usercp_enable_layout' => array(1, false),
    'usercp_enable_theme' => array(1, false),
    'usercp_enable_profile' => array(1, false),
    'usercp_enable_stats' => array(1, false),
    'usercp_enable_contributions' => array(1, false),
    'usercp_enable_notifications' => array(1, false),
    'usercp_enable_buddies' => array(1, false),
    'usercp_enable_message_options' => array(1, false),
    'usercp_enable_search' => array(1, false),
    'usercp_enable_delete' => array(1, false),
    'usercp_enable_authentication' => array(1, false),
    'usercp_enable_group_membership' => array(1, false),
    'usercp_enable_ignore_boards' => array(1, false),
   'usercp_field1image' => array('Your Image Here', false),
    'usercp_field1url' => array('Your URL Here', false),
    'usercp_field1maintext' => array('Your Text Here', false),
    'usercp_field1summary' => array('Your Text Here', false),
    'usercp_field1enable' => array('0', false),
    'usercp_field2image' => array('Your Image Here', false),
    'usercp_field2url' => array('Your URL Here', false),
    'usercp_field2maintext' => array('Your Text Here', false),
    'usercp_field2summary' => array('Your Text Here', false),
    'usercp_field2enable' => array('0', false),
    'usercp_field3image' => array('Your Image Here', false),
    'usercp_field3url' => array('Your URL Here', false),
    'usercp_field3maintext' => array('Your Text Here', false),
    'usercp_field3summary' => array('Your Text Here', false),
    'usercp_field3enable' => array('0', false),
    'usercp_field4image' => array('Your Image Here', false),
    'usercp_field4url' => array('Your URL Here', false),
    'usercp_field4maintext' => array('Your Text Here', false),
    'usercp_field4summary' => array('Your Text Here', false),
    'usercp_field4enable' => array('0', false),

   // 'variable name' => array(value, overwrite)
);
doSettings($addSettings);
?>
