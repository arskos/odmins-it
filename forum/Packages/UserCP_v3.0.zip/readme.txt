********************
UserCP V3.0
Created By Alan S
30/10/08
********************
V3.0 is the next step for the UserCP

It includes all the features of 2.0 with a few major changes.

The UserCP is now created using a array so the buttons are layed out depending on your forum permissions. This also makes it easier to manualy add
new buttons should the 4 preset ones be used.

The way the copyright and the error pages are displayed have been completely rewritten.

See the Admin Panel ( Admin -> Configuration -> Modifications -> UserCP ) for more options that have been added.

Big thanks to Kindred for the coding for the arrays.


For copyright removal info , Contact Alan S at alanscomputergenius[at]gmail[dot]com