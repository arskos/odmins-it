<?php
/*
UserCp Created By Alan S
Designed For SMF 2.0 Beta 4
UserCP V 3.0 30/October/2008
*/

 function template_main()

{

	global $scripturl, $webmaster_email, $txt, $context, $settings, $modSettings, $user_info;
loadLanguage('usercp');

// First of all set up the Error pages ( If Disabled or If Guest )

 {

      if($context['user']['is_guest'])
      usercp_guest();

      if(!$modSettings['usercp_enable'])
      usercp_disabled();
  }
  
// Now onto the UserCP

if (!$user_info['is_guest'] && !empty($modSettings['usercp_enable'])) {
	// <!-- Start off with the welcome text -->
	echo '<center>' , $txt['usercp_welcome'] , '<b>', $context['user']['name'] , '</b><br></center>';
	echo '<table border="0" width="100%" id="table1" cellspacing="1" style="border-collapse: collapse">';
	echo '<tr>';

  $count_usercp_buttons=0;

	foreach ($context['usercp_menu'] as $act => $cpbutton)
	{
    $count_usercp_buttons++;
		echo '
			<td align="center" width="25%" valign="top">
				<a href="', $cpbutton['href'], '" title="', $act , '"><img border="0" src="', $cpbutton['img'], '" width="80" height="80" ></a><br />
				<a href="', $cpbutton['href'], '" title="', $act , '">', $cpbutton['title'], '</a><br />',
				$cpbutton['txt'] ,'
			</td>';
    if ($count_usercp_buttons == 4) { 
				echo '</tr><tr>';
			  $count_usercp_buttons=0;
		}
	}

		echo '
			</tr>
   </table>
			<br />';
}

//If switch view option is enabled , Show it
if (!$user_info['is_guest'] && $modSettings['usercp_switchview'] && $modSettings['usercp_enable'])
echo '
 <center><font size="2pt"><a href="' ,$scripturl, '?action=profile;u=' ,$user_info['id'], '">Switch To Standard Profile View</a></font></center><br></br>';
// If Show Admin ID is enabled & the user is a admin
if ($context['user']['is_admin'] && $modSettings['usercp_enable'])
echo '
<center><font size="1pt">Your Member ID is ' ,$user_info['id'], '</font></center>';
// Show the copyright here if the usercp is enabled , we will show it somewhere else if its disabled.
{
if ($modSettings['usercp_enable'] && !$user_info['is_guest'])
 usercp_copyright();
}

}
function usercp_guest()
 {
      global $context, $txt, $scripturl;
      echo '
     <center> <table border="0" width="100%" class="tborder" cellspacing="' , ($context['browser']['is_ie'] || $context['browser']['is_opera6']) ? '1' : '0' , '" cellpadding="4" style="margin-bottom: 2ex;">
		<tr>
			<td class="catbg">' ,$txt['usercp_error'], '</td>
   </tr>
   <tr>
			<td valign="middle" align="center" height="60"> <b>',$txt['usercp_guest'],' <a href="',$scripturl,'?action=login">',$txt['usercp_login'],'</a> ',$txt['usercp_or'],' <a href="',$scripturl,'?action=register">',$txt['usercp_register'],'</a></b> </td>
  </td>
  </tr>';
  usercp_copyright();
   echo '
    </center></table>';
}
function usercp_disabled()
{
    global $context, $txt, $scripturl, $user_info;

 echo '

 <center> <table border="0" width="100%" class="tborder" cellspacing="' , ($context['browser']['is_ie'] || $context['browser']['is_opera6']) ? '1' : '0' , '" cellpadding="4" style="margin-bottom: 2ex;">
		<tr>
			<td class="catbg">' ,$txt['usercp_disabled'], '</td>
   </tr>
   <tr>
			<td valign="middle" align="center" height="60"> <b>' ,$txt['usercp_disabled'], ' , ' ,$txt['usercp_clickhere'], ' <a href="' ,$scripturl, '?action=profile;u=', $user_info['id'], '">' ,$txt['usercp_profile'],'</b> </td>

  </td>
  </tr>
  <tr>
  <td align="center">';

      usercp_copyright();

echo '

  </td>
  </tr>
    </center></table>';

}

?>

