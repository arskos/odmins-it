<?php
/*
UserCp Created By Alan S
Designed For SMF 2.0 Beta 4
UserCP V 3.0 30/October/2008
*/

if (!defined('SMF'))
	die('Hacking attempt...');
loadLanguage('usercp');
function usercp()
{
	global $context, $mbname, $txt;


	//Load the main usercp template
	loadtemplate('usercp');

	//Load the main usercp template
	$context['sub_template']  = 'main';
 //Set the page title
	$context['page_title'] = $mbname . ' - ' . $txt['usercp'];

	build_usercp();

}

function build_usercp()
{
	global $scripturl, $webmaster_email, $txt, $context, $settings, $modSettings, $user_info;
	
		$usercp_buttons = array(
			'account' => array(
				'title' => $txt['usercp_account_info'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=account',
				'img' => $settings['images_url'].'/usercp/ksysguard.png',
				'txt' => $txt['usercp_account_info_summary'],
				'show' => !empty($modSettings['usercp_enable_account']),
			),
			'layout' => array(
				'title' => $txt['usercp_look_and_layout'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=theme',
				'img' => $settings['images_url'].'/usercp/kivio.png',
				'txt' => $txt['usercp_look_and_layout_summary'],
				'show' => !empty($modSettings['usercp_enable_layout']),
			),
			'theme' => array(
				'title' => $txt['usercp_my_theme'],
				'href' => $scripturl . '?action=theme;sa=pick;u=' . $user_info['id'] . ';sesc=' . $context['session_id'],
				'img' => $settings['images_url'].'/usercp/blockdevice.png',
				'txt' => $txt['usercp_my_theme_summary'],
				'show' => !empty($modSettings['usercp_enable_theme']) && allowedTo(array('profile_extra_any', 'profile_extra_own')),
			),
			'profile' => array(
				'title' => $txt['usercp_my_profile'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=forumProfile',
				'img' => $settings['images_url'].'/usercp/kuser.png',
				'txt' => $txt['usercp_my_profile_summary'],
				'show' => !empty($modSettings['usercp_enable_profile']),
			),
			'stats' => array(
				'title' => $txt['usercp_my_stats'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=statPanel',
				'img' => $settings['images_url'].'/usercp/kchart.png',
				'txt' => $txt['usercp_my_stats_summary'],
				'show' => !empty($modSettings['usercp_enable_stats']),
			),
			'contributions' => array(
				'title' => $txt['usercp_my_posts'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=showPosts',
				'img' => $settings['images_url'].'/usercp/kedit.png',
				'txt' => $txt['usercp_my_posts_summary'],
				'show' => !empty($modSettings['usercp_enable_contributions']),
			),
			'notifications' => array(
				'title' => $txt['usercp_my_notifications'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=notification',
				'img' => $settings['images_url'].'/usercp/mailreminder.png',
				'txt' => $txt['usercp_my_notifications_summary'],
				'show' => !empty($modSettings['usercp_enable_notifications']),
			),
			'buddies' => array(
				'title' => $txt['usercp_buddies'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=editBuddies',
				'img' => $settings['images_url'].'/usercp/kdmconfig.png',
				'txt' => $txt['usercp_buddies_summary'],
				'show' => !empty($modSettings['usercp_enable_buddies']) && !empty($modSettings['enable_buddylist']),
			),
			'message_options' => array(
				'title' => $txt['usercp_message_options'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=pmprefs',
				'img' => $settings['images_url'].'/usercp/mail.png',
				'txt' => $txt['usercp_message_options_summary'],
				'show' => !empty($modSettings['usercp_enable_message_options']),
			),
			'search' => array(
				'title' => $txt['usercp_search'],
				'href' => $scripturl . '?action=search',
				'img' => $settings['images_url'].'/usercp/find.png',
				'txt' => $txt['usercp_search_summary'],
				'show' => !empty($modSettings['usercp_enable_search']),
			),
			'contact_pm' => array(
				'title' => $txt['usercp_contact_admin'],
				'href' => $scripturl . '?action=pm;sa=send;u=' . $modSettings['usercp_adminid'],
				'img' =>  $settings['images_url'].'/usercp/agent.png',
				'txt' => $txt['usercp_contact_admin_summary'],
				'show' => !empty($modSettings['usercp_usepm']) && !empty($modSettings['usercp_enablecontactadmin']),
			),
			'contact_email' => array(
				'title' => $txt['usercp_contact_admin'],
				'href' => 'mailto:' . $modSettings['usercp_contact_email'],
				'img' =>  $settings['images_url'].'/usercp/agent.png',
				'txt' => $txt['usercp_contact_admin_summary'],
				'show' => !$modSettings['usercp_usepm'] && !empty($modSettings['usercp_enablecontactadmin']),
			),
			'delete' => array(
				'title' => $txt['usercp_delete_account'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=deleteAccount',
				'img' => $settings['images_url'].'/usercp/delete.png',
				'txt' => $txt['usercp_delete_account_summary'],
				'show' => !empty($modSettings['usercp_enable_delete']) && allowedTo(array('profile_remove_any', 'profile_remove_own')),
			),

			'group_membership' => array(
				'title' => $txt['usercp_group_membership'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=groupMembership',
				'img' => $settings['images_url'].'/usercp/kgroup.png',
				'txt' => $txt['usercp_group_membership_summary'],
				'show' => !empty($modSettings['usercp_enable_group_membership']) &&  !empty($modSettings['show_group_membership']),
			),
			'ignore_boards' => array(
				'title' => $txt['usercp_ignore_boards'],
				'href' => $scripturl . '?action=profile;u=' . $user_info['id'] . ';sa=ignoreboards',
				'img' => $settings['images_url'].'/usercp/kignore.png',
				'txt' => $txt['usercp_ignore_boards_summary'],
				'show' => !empty($modSettings['usercp_enable_group_ignore_boards']) &&  !empty($modSettings['allow_ignore_boards']),
			),
			'usercp_field1' => array(
				'title' => $modSettings['usercp_field1maintext'],
				'href' => $modSettings['usercp_field1url'],
				'img' => $modSettings['usercp_field1image'],
				'txt' => $modSettings['usercp_field1summary'],
				'show' => !empty($modSettings['usercp_field1enable']),
			),
			'usercp_field2' => array(
				'title' => $modSettings['usercp_field2maintext'],
				'href' => $modSettings['usercp_field2url'],
				'img' => $modSettings['usercp_field2image'],
				'txt' => $modSettings['usercp_field2summary'],
				'show' => !empty($modSettings['usercp_field2enable']),
			),
			'usercp_field3' => array(
				'title' => $modSettings['usercp_field3maintext'],
				'href' => $modSettings['usercp_field3url'],
				'img' => $modSettings['usercp_field3image'],
				'txt' => $modSettings['usercp_field3summary'],
				'show' => !empty($modSettings['usercp_field3enable']),
			),
			'usercp_field4' => array(
				'title' => $modSettings['usercp_field4maintext'],
				'href' => $modSettings['usercp_field4url'],
				'img' => $modSettings['usercp_field4image'],
				'txt' => $modSettings['usercp_field4summary'],
				'show' => !empty($modSettings['usercp_field4enable']),
			),
		);

		$usercp_menu = array();
		foreach ($usercp_buttons as $act => $usercp_button)
			if (!empty($usercp_button['show']))
			{
				$usercp_button['active_button'] = false;
				$usercp_menu[$act] = $usercp_button;
			}
		$usercpMenuData = array($usercp_menu);

		list($context['usercp_menu']) = $usercpMenuData;

}

function usercp_copyright()
{
  echo '
 <tr>
  <td>
  <center><font size="1pt"><a href="mailto:alanscomputergenius@gmail.com">UserCP V3.0 &copy Alan S</a></font></center>
  </td>
  </tr>';
  


}
?>
