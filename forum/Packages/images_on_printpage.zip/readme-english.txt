[center][size=14pt][b]Images on Print Page[/b][/size][/center]
[hr]
[table][tr]
[td][b]Original Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=265135][b]Arantor[/b][/url][/td]
[td] | [b]Current Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=11359][b]Spuds[/b][/url][/td]
[/tr][/table]
[table][tr]
[td][b]Supported Languages:[/b] English, Spanish, Italian, Portuguese[/td]
[/tr][/table]
[table][tr][td]
[url=http://custom.simplemachines.org/mods/index.php?mod=2340][b]Link To Mod[/b][/url] | [url=http://www.simplemachines.org/community/index.php?topic=357442.0][b]Mod Discussion[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=11359][b]Other Mods by Spuds[/b][/url][/td]
[/tr][/table]
[hr]
[color=blue][b]Summary:[/b][/color]
Normally on the print-page view, images are hidden by links.

This mod adds a 'With images' and 'Text only' link to the page and flips it to display images accordingly.  In additon to the inline BBC IMG's it will also show attachment images (SMF 2.0 only)

The with images / text only links should not appear during printing on any modern, compliant browser - uses @media print, which even IE 6 should support ;)

[color=blue][b]Compatibility:[/b][/color]
Compatible with SMF 1.1 & 2.0

[color=blue][b]Change Log:[/b][/color]
[size=8pt][b]1.1 - 10 July 2011[/b]
+ 2.0 support added
+ Updated 2.0 branch to also print out attachments
[size=8pt][b]1.0 - December 29, 2009[/b]
First release
[/size]