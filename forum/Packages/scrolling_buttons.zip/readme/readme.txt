[center][img]http://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Cc-by_new_white.svg/25px-Cc-by_new_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Cc-nc_white.svg/25px-Cc-nc_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Cc-sa_white.svg/25px-Cc-sa_white.svg.png[/img][hr][color=red][size=16pt][b]Scrolling Buttons[/b][/size][/color]
[color=blue][b][size=10pt]By Bugo[/size][/b][/color]

[color=green]Go Up/Go Down buttons for screen scrolling, with jQuery.[/color]
Powered by MaxSite CMS's [url=http://jenweb.info/page/plugin-gotopbottom-for-maxsite]plugin[/url].[/center][hr]This work is licensed under a [url=http://creativecommons.org/licenses/by-nc-sa/3.0/]CC BY-NC-SA[/url]