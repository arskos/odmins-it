<?php

$txt['smi_title'] = 'Social Media Icons';
$txt['smi_array'] = '"Share this topic on Twitter", "Share this topic on Google Buzz", "Share this topic on FriendFeed", "Share this topic on Facebook", "Send this topic to Linkedin", "Share this topic on MySpace", "Share this topic on Live Journal", "Share this topic on Delicious", "Share this topic on Google", "Send this topic to Digg", "Send this topic to Blogger", "Send this topic to Technorati", "Share this topic to Mister Wong"';
$txt['smi_app'] = 'Icons set';
$txt['smi_app_set'] = 'Normal|Round';
$txt['smi_aeva'] = 'Show a block with these icons on the pages of the Aeva Media gallery';

?>