[center][img]http://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Cc-by_new_white.svg/25px-Cc-by_new_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Cc-nc_white.svg/25px-Cc-nc_white.svg.png[/img] [img]http://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Cc-sa_white.svg/25px-Cc-sa_white.svg.png[/img][hr][color=red][size=16pt][b]Nickname to Reply[/b][/size][/color]
[color=blue][b][size=10pt]By Bugo[/size][/b][/color]

[color=green]New ability => Insert nicknames to the Quick/Full Reply.[/color]
Compatible with [url=http://custom.simplemachines.org/mods/index.php?mod=111]Member Color Link[/url].[/center][hr]This work is licensed under a [url=http://creativecommons.org/licenses/by-nc-sa/3.0/]CC BY-NC-SA[/url]