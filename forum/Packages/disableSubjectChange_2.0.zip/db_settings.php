<?php
// Disable Subject Change Database Settings
// by tyty1234 (http://www.tytyweb.net/smf/)

// Find SMF's SSI, and check if we're in SMF. If SSI found, but SMF wasn't defined, it's being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require(dirname(__FILE__) . '/SSI.php');
// No SSI and SMF? What more can we do?
elseif (!defined('SMF'))
	die('<strong>Error:</strong> Cannot install modification...please make sure this file is in the same folder where SMF is.');

// Here are the db_settings we are adding/removing.
$db_settings = array(
	array('disableSubjectChange', 0),
);

// If we're not in the package manager, we can't use $context['uninstalling'].
if (isset($context['uninstalling']))
{
	// Are we installing?
	if (!$context['uninstalling'])
		InstallModification($db_settings);
	// Otherwise we're uninstalling.
	else
		UninstallModification($db_settings);
}
else
{
	// Use ?action to controll install and uninstall.
	if (isset($_REQUEST['action']))
	{
		// Are we installing?
		if ($_REQUEST['action'] == 'install')
			InstallModification();
		// Are we uninstalling?
		elseif ($_REQUEST['action'] == 'uninstall')
			UninstallModification();
		// Undefined...
		else
			die('<strong>Error:</strong> Undefined action - ' . $_REQUEST['action'] . '. Use "install" or "uninstall".');
	}
	else
		die('<strong>Error:</strong> Please use the ?action request variable to control install or uninstall.');
}

function InstallModification($settings)
{
	global $smcFunc;

	// Insert the settings into the database.
	$smcFunc['db_insert']('replace',
		'{db_prefix}settings',
		array('variable' => 'string-255', 'value' => 'string-65534'),
		$settings,
		array('variable')
	);
}

function UninstallModification($settings)
{
	global $smcFunc;

	// Delete the settings from the database.
	foreach ($settings as $v)
	{
		$smcFunc['db_query']('', '
		   DELETE FROM {db_prefix}settings
		   WHERE variable = {string:row}',
		   array(
				'row' => $v[0],
		   )
		);
	}
}

?>