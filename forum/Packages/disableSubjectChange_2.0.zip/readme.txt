[color=blue][size=14pt][b]Disable Subject Change[/b][/size][/color]

[b]Written by:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=159909]tyty1234[/url]
[b]Current Version:[/b] 2.0
[b]Compatible With:[/b] SMF 2.0

[hr]

[color=blue][size=12pt]Summary[/size][/color]
This mod adds an option in the admin panel to disable the ability to change the subject of a topic when replying to that topic. This option can be accessed via Admin -> Forum -> Post and Topics.

[color=blue][size=12pt]Installation[/size][/color]
This mod should be installed using the [b]Package Manager[/b]. No manual edits should be necessary, but if it comes to that resort, please use the [url=http://www.tytyweb.net/projects/smf/package-parser/]Package Parser[/url].

[color=blue][size=12pt]Changelog[/size][/color]
[b]What's new in this version?[/b]
Released for SMF 2.0 
Enabled subject changing for all moderators (board moderators, global moderators)
Slight change of code.
Dropped SMF 1.1.x compatibility. DO NOT use this version for SMF 1.1.x