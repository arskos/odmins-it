[center][color=red][size=16pt][b]KeyCAPTCHA for SMF[/b][/size][/color]
[size=14pt][color=orange]v.2.3[/color][/size] 
[color=green][b][size=12pt]Athor of Modification: [url=http://www.simplemachines.org/community/index.php?action=profile;u=224979]0daliska[/url][/size][/b][/color]
[color=blue][b][size=12pt]Original author of the code: [url=http://www.simplemachines.org/community/index.php?action=profile;u=273151]KeyCAPTCHA[/url][/size][/b][/color]
[/center]
[hr]
[size=13pt][color=maroon][u][b]Introduction[/b][/u][/color][/size]
[center]KeyCAPTCHA has two modes of operation: Flash and HTML5. When loaded KeyCAPTCHA defines the mode required in the visitor’s web browser automatically.[/center]

[center]A visitor of your site is offered not to guess the content but restore some objects of the task provided and thus it makes interactivity of our CAPTCHA positively different from the other CAPCHAs. The variety of the tasks also increases protection of your site against spam.[/center]

[center]For more information go to: [url=https://www.keycaptcha.com/]https://www.keycaptcha.com/[/url][/center]
[hr]
[size=13pt][color=maroon][u][b]Features[/b][/u][/color][/size]

[list]
[li]KeyCAPTCHA server is responsible for the random placement of the immovable objects and thus makes it impossible for different spam bots to identify their coordinates in the initial code of a page.[/li]
[li]KeyCAPTCHA server checks each solution of the tasks and thus the page protected by KeyCAPTCHA contains no information at all about the correct answer. For this reason, spam-bots are completely unable to get the correct answer.[/li]
[li]The whole data exchange between your web-server, a visitor's web-browser and KeyCAPTCHA server is protected by digital signature.[/li]
[li]The keys to check the original data transmitted are stored in KeyCAPTCHA server and in the private part of your web server. To increase thelevel of security, the keys are unique for each site and have variable length of 112-165 bits. All these suggest that spam bots are completely deprived of possibility to forge the transmitting data.[/li]
[/list]
[hr]
[size=13pt][color=maroon][u][b]How to Use[/b][/u][/color][/size]
----------
You can enable KeyCAPTCHA by going to:

[color=blue][b][size=12pt]SMF 1.1:[/size][/b][/color]
Admin -> Registration -> Settings

[color=blue][b][size=12pt]SMF 2.0:[/size][/b][/color]
Admin -> Security and Moderation -> Anti-spam

[color=red][size=16pt]A Private Key and KeyCAPTCHA Code are required for operation of KeyCAPTCHA. To receive your Private Key and KeyCAPTCHA Code you should register at www.keycaptcha.com.[/size][/color]

[color=#572500][b]Installation[/b][/color]
Any previous versions of this mod [b]MUST[/b] be uninstalled [b]BEFORE[/b] installing this version.

[hr]
[b]Changelog:[/b]

v 1.0 - November, 2010 
SMF 1.1.x Compatible only

v 2.0 - March, 2011
+ SMF 2.0 RC3 - RC5 Compatible
+ SMF 1.1.x add comments for admin settings
+ SMF 1.1.x add the keycaptcha at PM
o Upgrade the keycaptcha_class to version v3.4.0

v 2.1 - June, 2011
+ SMF 2.0 Gold Compatible

v 2.2 - June, 2011
! Fixed loading of CAPTCHA in personal messages for SMF1.1.X 

v 2.3 - January, 2012
+ SMF 2.0.2 Compatible
[hr]
[b]License[/b]
-------
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License version 2 as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
[hr]
[size=13pt][color=maroon][u][b]Acknowledgements[/b][/u][/color][/size]
----------------
"SMF" and "Simple Machines" are trademarks of Simple Machines LLC. 



Mersane, Ltd (c) 2011-2012
