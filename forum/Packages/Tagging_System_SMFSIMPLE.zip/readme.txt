[center][img width=443 height=115]http://bit.ly/kZVDB6[/img]

[glow=black,2,300][color=purple][size=16pt][b]Tagging System SMFSIMPLE[/b][/size][/color][/glow]
[b]Developed by [url=http://www.smfsimple.com/index.php?action=profile;u=55]4Kstore[/url]  and  [url=http://www.smfsimple.com/index.php?action=profile;u=2501]Manix[/url] for [url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[i][b]SMF 2.0 - 2.0.X[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com
Official Support in [url=http://www.SmfSimple.com]www.SmfSimple.com[/url][/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Complete Tagging System for SMF[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Sistema de etiquetas completo para SMF[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
1. Hooks used
2. Ajax for tag autocomplete
3. Css3 For each tags
4. List of tags in topic display
5. Related Topics by tags
6. Tag Cloud Customizable
7. List of all tags
8. Search List of topics by tags (Paginated)
9. Settings for create tags.

Administration:
Enable - Disable the mod.
Required tags.
Disable tags in X boards
Maximum number of tags per topic
Minimum Tag Length
Maximum Tag Length 
Maximum number of suggested tags 
Enabled Related Topics by Tags 
Maximum related topics to show
Enable Tag Cloud
Enable List tags
Settings for the style of the cloud Tag
Limits of tags in the cloud
MORE... Much More...

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
1. Usa Hooks para la mayoria de las ediciones.
2. Sugerencia de tags usando ajax
3. Dise�o CSS3 para los tags
4. Listado de tags en cada tema
5. Temas relacionados por tags
6. Nube de tags
7. Listado de todos los tags
8. Mostrar todos los temas por tags
9. Configuracion para cada tag

Administracion:
Habilitar - Deshabilitar el mod.
Tags requeridos
Deshabilitar tags en X foros
Numero maximo de tags por tema
Minima cantidad de letras por tag
Maxima cantidad de letras por tag
Maximo numero de tags sugeridos
Habilitar Temas relacionados por tags
Maxima cantidad de temas a mostrar en temas relacionados
Habilitar nube de tags
Habilitar lista de todos los tags
Configuraciones para el dise�o de la nube de tags
Numero maximo de tags en la nube
Mucho.. mucho mas!

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]English & Spanish[/b][/color]
[hr]

[color=purple][size=14pt][b]Settings[/b][/size][/color]
Administration Center � Configuration � Tagging System

[color=red][size=14pt][b]Notes:[/b][/size][/color]
This Mod Uses Jquery.
This Mod Uses CSS3.
This Mod Uses Hooks.

Icons:
Creative Commons Attribution 3.0 License - http://pc.de/icons/ 

[color=purple][size=14pt][b]License:[/b][/size][/color]
 * This SMF modification is subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]
 
[center][glow=black,2,300][color=green][size=15pt][b]Tagging System SMFSIMPLE[/b][/size][/color][/glow][/center]