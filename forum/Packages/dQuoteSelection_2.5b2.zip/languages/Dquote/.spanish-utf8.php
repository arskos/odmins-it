<?php

$txt['dQuoteSelection_txt'] = 'Quote (selección)'; 
?>
