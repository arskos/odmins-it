<?php

$txt['dQuoteSelection_txt'] = 'Цитировать (выделенное)';
?>