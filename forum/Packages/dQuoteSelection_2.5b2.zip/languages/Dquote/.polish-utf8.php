<?php

$txt['dQuoteSelection_txt'] = 'Cytuj (zaznaczone)';
?>