<?php

$txt['dQuoteSelection_txt'] = 'Quote (seleccion)'; 
?>