<?php

$txt['dQuoteSelection_txt'] = 'Al?nt? Yap (Secim)';
?>
