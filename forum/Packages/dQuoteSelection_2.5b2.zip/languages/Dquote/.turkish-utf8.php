<?php

$txt['dQuoteSelection_txt'] = 'Alıntı Yap (Seçim)';
?>