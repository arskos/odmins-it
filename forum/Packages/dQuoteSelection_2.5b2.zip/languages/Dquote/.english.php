<?php

$txt['dQuoteSelection_txt'] = 'Quote (selected)';
?>