<?php

global $txt;

$txt['lang'] = 'ru';
$txt['wiki'] = 'Wiki';
$txt['wiki_desc'] = 'Поиск в базе знаний Wikipedia';


?>