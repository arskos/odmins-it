                 [center][color=green]Wikipedia BBC Language Pack[/color][/center] 
                       [center][color=blue]Author:[/color][/center]
                    [center][color=orange]Masterd[/color][/center] 

This pack will add additional languages for Wikipedia BBC mod by Masterd. Here's the list of all avaliable languages.

[list]
[li]Russian (Thanks to [url=http://www.simplemachines.org/community/index.php?action=profile;u=229017]Bugo[/url].)[/li]
[/list]