[size=13pt][b][color=#404040]Brief Summary:[/color][/b][/size]
[hr]
Advanced Recent Posts replaces the normal Recent Posts block with a very neatly laid out table with mouseover affects!

Future versions of this mod, will include full admin controls. I've had this mod on a local site of mine since August 09 and just wanted to shoot out a very simple version and update it later.
[hr]

[size=13pt][b][color=#404040]Changelog:[/color][/b][/size]
[hr]
[b][color=#404040]v1.1.1 (r2.9.12):[/color][/b]
[list]
[li]!enhancement: mostly rewritten. now compatible with smf 2.0 branch.[/li]
[li]!bugfix: utf8 language strings now stored in separate install file, encoded with utf8.[/li]
[/list]
[hr]

[size=13pt][b][color=#404040]Mentions:[/color][/b][/size]
[hr]
[list]
[li]Version: 1.1.1[/li]
[li]Written by: Labradoodle-360[/li]
[li]Copyright: Matthew Kerle - All Rights Reserved[/li]
[li]Dedicated To: LILM[/li]
[/list]
[hr]