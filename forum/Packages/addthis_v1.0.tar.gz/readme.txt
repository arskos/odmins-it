[img]http://i48.tinypic.com/2i9nvgi.jpg[/img]

[table]
[tr]
[td][b]Written by:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=182638][b]Labradoodle-360[/b][/url][/td]
[/tr][tr]
[td][b]Current version:[/b] 1.0[/td]
[/tr]
[tr]
[td][b]Updates:[/b] Mod Support Topic[/td]
[/tr]
[tr]
[td][b]Suitable for:[/b] SMF 2.0 RC2, SMF 2.0 RC3[/td]
[/tr]
[tr]
[td][b]Supported languages:[/b] [img]http://www.simplemachines.org/site_images/lang/english.gif[/img][/td]
[/tr]
[tr][td][b]Translators:[/b] Translations are welcome and appreciated![/td][/tr][/table]

[url=http://www.SimpleMachines.org/community]Link to Mod[/url] | [url=https://www.paypal.com/cgi-bin/webscr&cmd=_s-xclick&hosted_button_id=10240245]Donate[/url]

[hr]


[size=12pt][color=blue]Summary[/color][/size]

AddThis is the #1 Bookmarking & Sharing Service.

Official Website: [url=http://www.AddThis.com]AddThis.Com[/url]

AddThis Mod is permission based, so you can control [b]who[/b] can share.
By using AddThis Click Stats/Analytics you can track clicks, by entering your username in the username field.

AddThis allows you to share anything
[list]
[li]On the Calendar[/li]
[li]On Boards[/li]
[li]On Topics[/li]
[li]On Posts[/li]
[li]On the Help page[/li]
[li]On the Memberlist[/li]
[li]On the Printpage[/li]
[li]On Profiles[/li]
[li]And Forum Stats[/li]
[/list]

By using the "Customize AddThis" field, you can customize the appearance and action of your bar, exclude a service, include a service, make your own.

AddThis already supports over 250 different social networking websites (with the ability to add more.)

[size=12pt][color=blue]Installation[/color][/size]

[b]Package Manager[/b] should work in most cases. If you need to make any edits, the full list can be obtained from the Parse function on the right..

[b]Useful links[/b]
[url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation Of Mods[/url]
[url=http://www.simplemachines.org/community/index.php?topic=24110.0]How Do I Modify Files?[/url]

[size=12pt][color=blue]Support[/color][/size]

Questions should be address to the [url=http://www.simplemachines.org/community]mod support topic[/url].

[size=12pt][color=blue]Updating[/color][/size]

Updates will be added here.

[size=12pt][color=blue]Changelog[/color][/size]

[b]1.0[/b] - 08.03.2010
First release AddThis

[size=12pt][color=blue]15 Files modified by AddThis[/color][/size]
./Sources/Admin.php
./Sources/Load.php
./Sources/ManagePermissions.php
./Sources/ManageSettings.php
./Themes/default/Calendar.template.php
./Themes/default/Display.template.php
./Themes/default/Help.template.php
./Themes/default/Memberlist.template.php
./Themes/default/MessageIndex.template.php
./Themes/default/Printpage.template.php
./Themes/default/Profile.template.php
./Themes/default/Stats.template.php
./Themes/default/languages/Help.english.php
./Themes/default/languages/ManagePermissions.english.php
./Themes/default/languages/Modifications.english.php