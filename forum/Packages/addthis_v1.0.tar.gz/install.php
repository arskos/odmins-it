<?php
###################################################################
# To run this install manually please make sure you place this    #
# in the same place and SSI.php and index.php                     #
###################################################################

global $smcFunc, $db_prefix, $context, $boarddir, $modSettings, $scripturl, $boardurl, $sourcedir;


if (!defined('SMF') && file_exists(dirname(__FILE__) . '/SSI.php')) {
    require_once(dirname(__FILE__) . '/SSI.php');

}
elseif (!defined('SMF'))
    die('The installer wasn\'t able to connect to SMF! Make sure that you are either installing this via the Package Manager or the SSI.php file is in the same directory.');

        updateSettings(array(
		'enable_addthis' => 0,
		'addthis_button_type' => 1,


        ));

// If we're using SSI, tell them we're done
if(SMF == 'SSI')
    echo 'Database changes are complete!';

?>
