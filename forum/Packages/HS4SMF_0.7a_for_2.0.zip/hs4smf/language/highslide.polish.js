// by 'user9999', published at Highslide JS forum
// http://highslide.com/forum/
hs.lang = {
loadingText :  '�adowanie...',
loadingTitle : 'Kliknij, aby anulowa�',
focusTitle :'Kliknij, aby przenie�� na wierzch',
fullExpandTitle : 'Rozszerz do pe�nego rozmiaru',
fullExpandText :  'Pe�ny rozmiar',
creditsText :  'Korzysta z <i>Highslide JS</i>',
creditsTitle : 'Przejd� do strony domowej Highslide JS',
previousText : 'Wstecz',
previousTitle :'Wstecz (lewa strza�ka)',
nextText :  'Dalej',
nextTitle : 'Dalej (prawa strza�ka)',
moveTitle : 'Przesu�',
moveText :  'Przesu�',
closeText : 'Zamknij',
closeTitle :'Zamknij (esc)',
resizeTitle :  'Zmie� rozmiar',
playText :  'Uruchom',
playTitle : 'Uruchom pokaz slajd�w (spacja)',
pauseText : 'Pauza',
pauseTitle :'Wstrzymaj pokaz slajd�w (spacja)',
restoreTitle : 'Kliknij, aby zamkn�� obrazek; kliknij i przeci�g, aby przesun��. U�yj klawiszy strza�ek, aby przej�� dalej lub wstecz.'
}; 