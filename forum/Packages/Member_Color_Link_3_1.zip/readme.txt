[center][size=14pt][color=green]Member Color Link v3.1 - [url=http://www.smfpacks.com/]NIBOGO[/url][/color][/size]
[color=green]This Mod change the link of the Members so that the color of the Group is the link color.
[/color][/center][hr][center][url=http://www.simplemachines.org/community/index.php?topic=32101.0][b]Support topic[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?mod=111][b]Link to Mod[/b][/url] | [url=http://www.smfpacks.com][b]Website[/b][/url] |� [url=http://www.smfpacks.com/donate.php][b]Donate[/b][/url][/center][hr]

[b]Important Info[/b]:
o This Mod was created by SMFPacks.com - The #1 Website for the Customziation of your SMF.

SMFPacks.com Provides Other Great Packages:
- Member Color Link
- Reason for Editing Mod.
- Yet Another Global Announcements Mod.
- SMF Social Groups.
- SMF Links Directory.
- SMF Downloads Directory.
- SMF Dynamic Directory.
- Advanced Topic Prefix Mod.
- Advanced Invitations System.
- Move Topic Notification.
- PM to New Members.
- Permissions Info.
- Next Post Level.
- Karma Buttons.
- SMF Multi Quote.
- Attachments in Topics.
- and much more visit us on SMFPacks.com

[b]
Developer:[/b]:
[url=http://www.smfpacks.com/]NIBOGO[/url]
[b]
Original author:[/b]:
[url=http://www.simplemachines.org/community/index.php?action=profile;u=10466]DIN1031[/url]

[b]Languages[/b]:
Follow Languages are included:
English (utf8), Italiano (utf8) (Italian), and Deutsch (utf8) (German)

Follow Outdated Languages are included:
Espa�ol (Spanish), T�rk�e (utf8) (Turkish), Nederlands (utf8) (Dutch), Portugu�s (utf8) (Portuguese), Brazilian, Svenska (Swedish) (utf8)

I welcome translations for any language, please post it on the support topic.

[b]Compatibility[/b]:
- 2.0
- 1.1.14[hr]

[size=4]Changelog:[/size]

[b]Version 1.8.7[/b]:
- Mulitinstaller Package
[hr]
[b]Version 2.0.0-2.1.6[/b]:
* Overworked my Mod System.
* The languages are now included in the package, and will be skiped if it not avaible. I split also the english version out of the mod, so it's simpler for translater to made own translations.
+ The only changes are for 1.1+ i add now the color for guest nicks and replaced all <font> html tag with <span style="color:xx;"> tags.
+ Add Guest Colors also to the Recent Pages
+ Add to the MemberContext a colored_name and colorless_link variable, for some user how need some custom things without colors or without link.
- [iurl=http://www.simplemachines.org/community/index.php?topic=32101.msg1242883#msg1242883]Fix a mistake in the Spain Translation...[/iurl]
+ Add a color for Banned User.
- Upgrades Included (Some Languages are Outdated, but i will add at least English translations to the language files.
+ Add the Option for Color the Moderators Links (and only the Links for Moderator Lists).
! Removed a eval bug, thats in it since Version 1.2.7...
- Upgrade included (For SMF 1.1.x Versions)
- Fixed a forgotten letter in the package.xml
! Bug Fix 'id_cat' eval in Subs-BoardIndex.php (2.0 Beta 3 only)
+ Add a function to load colors in a faster way, this should help other Mod Autors integrate the colors into the mod
+ Add a 'online_color' to the memberContext array
- First Step to a complete overwork of the Mod done. 
! Eval Bugfix in the Subs-Recent.php (Only 2.0 Beta 3)
! Bug Fix 'id_cat' eval in Subs-BoardIndex.php (2.0 Beta 3 only) (second one)

[hr]
[b]Version 3.0.0[/b] (24.05.08):
[u]Changes for SMF 1.1.5+ and 2.0. Beta 3+[/u]:
* Complete overwork of the Mod (Should be faster now, i calculate a 20% speed up)
* Integrate a new Function for fast loading of colors, it take every possible way to use the chache of smf
* New Function for other Mod Creators for easy handling of colored links (Ask if you need help)
+ Replace all <span> tags into the link of the poster (use style), but you can go back to old mode.
+ Add a Option to load all colors on serach result (Some work standard without extra load)
+ Add Guest Color to some more pages
+ Add Birthday Link Color (Yeah only for fun, but why not ;D)
+ Extent Color Field in Database to 255 with that you can user more css style tags

[u]Changes only for SMF 1.1.x[/u]
+ Fix colors on the Overview in Membergroups, to see the current Membergroupcolor

[u]Changes only for SMF 2.0.x[/u]
+ Color the complete Moderation Center
+ Color the Warning Issue Page

At Least:
- Currently all Lanugages exept english and german are outdate, please help me to tanslate the missing things
- For Uprade to this Version you need to uninstall the old version!

[hr]
[b]Version 3.0.1/3.0.2[/b] (21.06.08):
[u]Bugfixes for Both SMF Versions:[/u]
! A Possible Eval Bug fixed in MessageIndex.php (Should normal not happen!)

[u]Only Bux Fixes for SMF 1.1.x[/u]
! A Possible Eval Bug fixed in BoardIndex.php (Shoul normal not happen!)
! Language Eval Bug fixed in Search.php (Reported by Kalina)
! A Possible Eval Bug fixed in Recent.php (Should normal not happen!)
! A Possible Eval Bug fixed in Stats.php (Shoul normal not happen!)

[u]Only Bug Fixed for SMF 2.0.x[/u]
! Double insert on the MemberContext Variable fixed (Mod is not deinstallabled!)

- Upgrade from Version 3.0.0/3.0.1 included for both versions ;)
[hr]
[b]Version 3.0.3[/b] (26.08.08):
! Forgotten > in Calander.template.php and BoardIndex.template.php, this will not show the nickname if no color is set (SMF 1.1.x only)
! Removed the bug with the disappearing color if not a birthday color is set (SMF 2.0.x/ 1.1.x) 
- Upgrades Included
[hr]
[b]Version 3.0.4[/b] (02.09.08):
! Not correct selected chache data bug is removed (SMF 2.0.x/ 1.1.x) 
- Upgrades Included
[hr]
[hr]
[b]Version 3.0.5[/b] (08.09.08):
! Prevent possible eval bug, by removing not needed items (SMF 2.0.x/ 1.1.x) 
* Make the Package SMF 2.0 Beta 4 Compatible
- Upgrades Included
[hr]
[b]Version 3.0.5a[/b] (26.09.08):
! Fix a not reomved line on (SMF 2.0.x) (This Bugfix will only work on smf 2.0.x).
- Removed the SMF 2.0 Beta 3.1 Public Compatible
- Upgrade for SMF 2.0 Beta 4 included, SMF 1.1.x will need to be updated to this version!
[hr]
[b]Version 3.0.6[/b] (10.02.08):
! Bug Fix on SMF 2.0, i replace a color with a link instead of the color. (Thanks to Bulakbol that you find this bug)
! Version confusing bug fix... with this the member color version detection will be everytime on the correct one! (Possible Upgraded Versions could not be updated because of this...) ;).
[hr]
[b]Version 3.0.7[/b] (11.06.09):
! I don't know which mod conflict with it but normal this should not happen, but now there should be no errors anymore ;).
- Like every time the upgrade is included.
[hr]
[b]Add Ons and Fixes for this Mod[/b]
[iurl=http://www.simplemachines.org/community/index.php?topic=32101.0]All this Fixes or Add Ons are arttached to this post[/iurl]
[hr]
Name: SSI Member Color Link
File: SSIMemberColorLinkXXX.zip
Description: The SSIMemberColor Files add color to the ssi includes who made with the SSI.php.  Some people want this :). 
[hr]
[b]Version 0.9.9[/b]
!*+- First Release
[hr]
[b]Version 0.9.9 (30.07.07)[/b]
- Compatible to 1.1.3 
[hr]
[b]Version 1.0.0 (04.08.07)[/b]
! Fix a error when only one user is loaded and the $color_profile array is empty.
- Upgrade Included
[hr]
[b]Version 1.0.1 (09.08.07)[/b]
! Correct a mistake i made in link built, you will see it sometimes in the internet explorer
* Easier Handling in the ssi_loadColor function
- Upgrade Included
[hr]
[b]Version 1.0.2 (28.08.08)[/b]
+ Integrate the new load_OnlineColors function (Special Colors will work now) 
- Upgrade Included
[hr]
[b]Version 1.0.5 (04.09.08)[/b]
! Forgot to create the link for the loaded member color link data...
+ Fixed up a load bug, that could happen if only cached datas is load
! Used a nice reworked version of the load color datas for smf 2.0 (LHVBM, give me that idea ;P) 
- Currently upgrade first to 1.0.2 after that you can upgrade to 1.0.5

- This Mod Work for SMF1.0.x-1.1.x and for the SMF 2.0 Beta 3.1

[hr]
Name: SMFModaratorFix100
File: SMFModaratorFixXXX.zip
Description: Fix the Problem with the Replacement of the Admin/Gmod colors if a Admin or Gmod is Moderator of a board.
[hr]
[b]Version 1.0.0[/b]
!*+- First Release

[HR]
Legend:
! Bugfix
+ New Feature
* Changed
- Info Only