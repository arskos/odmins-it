<?
/*****************************************************************
* install.php  Version 1.0.2                                     *
* Special Advanced Version for Easier Handling                   *
* Programmed / Copyright By DIN1031 (http://www.ayu-kult.de/)    *
* for SMF (http://www.simplemachines.org)                        *
*****************************************************************/
/*****************************************************************
* It's free to change and use everywhere who this file is        *
* useable and made his work. You can change the code as you like *
* it. The only thing that i wish is, add the first 7 Lines of    *
* this file                                                      * 
* THANKS A LOT                                                   *
*****************************************************************/
/*****************************************************************
* Used for follow Software                                       *
* Programm:      MemberColorLink                                 *
* By:            DIN1031 (http://www.ayu-kult.de/)               *
* Copyright:     DIN1031 (http://www.ayu-kult.de/)               *
*****************************************************************/

global $db_prefix, $modSettings;

//This is a way to install the mod without the package parser!
$SSI_INSTALL = false;
if(!isset($db_prefix)) {
	require('SSI.php');
	$SSI_INSTALL = true;
}

//I can't install it if this on <<
$old_querycheck = isset($modSettings['disableQueryCheck']) ? $modSettings['disableQueryCheck'] : 0;
$modSettings['disableQueryCheck'] = 1;

//Upgrade a field so that it store more informations ;D
db_query("ALTER TABLE {$db_prefix}membergroups CHANGE onlineColor onlineColor VARCHAR( 255 ) NOT NULL", __FILE__, __LINE__);

//Okay Work done ;) (Replace the Varibale back...)
$modSettings['disableQueryCheck'] = $old_querycheck;

//Give a proper answer on ssi install ;)
if($SSI_INSTALL)
	echo 'DB Changes should be made now...';
?>