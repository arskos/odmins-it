<?php
/**********************************************************************************
* installDatabase.php                                                             *
***********************************************************************************
* SMF Torrent                                                                     *
* =============================================================================== *
* Software Version:           SMF Torrent 0.1 Alpha                               *
* Software by:                Niko Pahajoki (http://www.madjoki.com)              *
* Copyright 2008 by:          Niko Pahajoki (http://www.madjoki.com)              *
* Support, News, Updates at:  http://www.madjoki.com                              *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

global $txt, $boarddir, $sourcedir, $modSettings, $context, $settings, $db_prefix, $forum_version, $smcFunc;
global $db_package_log, $issueSettings, $issueTables, $issuePermissions, $issue_version, $issueRename;
global $db_connection, $db_name;

// Ugh...
if (!isset($forum_version))
{
	require_once(dirname(__FILE__) . '/index.php');
}

require_once($sourcedir . '/TorrentDatabase.php');

$tbl = array_keys($tables);

// Add prefixes to array
foreach ($tbl as $id => $table)
	$tbl[$id] = $db_prefix . $table;

db_extend('packages');

doTables($tables);
doSettings($addSettings);
doPermission($permissions);

// Create scheduled task
$smcFunc['db_insert']('ignore',
	'{db_prefix}scheduled_tasks',
	array(
		'next_time' => 'int',
		'time_offset' => 'int',
		'time_regularity' => 'int',
		'time_unit' => 'string',
		'disabled' => 'int',
		'task' => 'string-24',
	),
	array(
		0,
		0,
		1,
		'd',
		0,
		'tracker_scrape',
	),
	array('task')
);

?>