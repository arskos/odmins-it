[center][img]http://bit.ly/kZVDB6[/img][/center]

[center][glow=black,2,300][color=purple][size=16pt][b]Topic View Log[/b][/size][/color][/glow]
[b]Developed by[/b] [b][url=http://www.smfsimple.com/index.php?action=profile;u=55]4kstore[/url][/b] [b]for [/b][b][url=http://www.smfsimple.com]SMFSimple.com[/url][/b]
[b]Created by[/b] [b][url=http://www.simplemachines.org/community/index.php?action=profile;u=118168][SiNaN][/url][/b]
[i][b]SMF 1.1.X AND 2.0.1[/b][/i][/center]

[hr]

[center][glow=black,2,300][color=orange][size=14pt][b]El soporte oficial de los desarrolladores de nuestros mods lo encontraras en SMFSimple.com[/b][/size][/color][/glow][/center]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Description:[/b][/u][/size][/color][/glow]
[i][b]Time to see who viewed a topic. This modification enhances the topic log function of SMF and gives you the ability to view the log of the topic you want.[/b][/i]

[glow=black,2,300][color=orange][size=13pt][u][b]Descripcion:[/b][/u][/size][/color][/glow]
[i][b]Con este mod usted podra ver un completo log de los usuarios que visitaron un tema[/b][/i]

[hr]

[glow=black,2,300][color=orange][size=13pt][u][b]Features:[/b][/u][/size][/color][/glow]
[list]
	[li]Display view count for each member[/li]
	[li]Display post count for each member in topic[/li]
	[li]Display last view time[/li]
    [li]8 ways of sorting the list[/li]
	[li]Pagination[/li]
	[li]2 types of 'View Topic Log' permission[/li]
	[li]Show log topic name in who's online[/li]
[/list]

[glow=black,2,300][color=orange][size=13pt][u][b]Caracteristicas:[/b][/u][/size][/color][/glow]
[list]
	[li]Muestra cantidad de visitas de cada usuario[/li]
	[li]Muestra cantidad de respuestas de cada usuarios en ese topic[/li]
    [li]Muestra la ultima vez que visito el tema[/li]
	[li]8 formas de ordenar las tablas[/li]
	[li]Paginacion[/li]
    [li]2 tipos de permisos[/li]
	[li]Muestra log topic en la lista de Who`s online[/li]
[/list]

[hr]

[center][glow=black,2,300][color=red][size=13pt][b]Screenshots | Imagenes[/b][/size][/color][/glow][/center]

[center]
[IMG]http://i.imgur.com/L1Tm4.png[/IMG]
[IMG]http://i.imgur.com/2xAO4.png[/IMG]
[IMG]http://i.imgur.com/tkz35.png[/IMG]
[/center]

[hr]
[color=teal][u][b]Language Support | Lenguajes Soportados[/b][/u][/color]
[color=teal][b]- English
- Spanish_latin
- Spanish_latin-utf8
- Spanish_es
- Spanish_es-utf8
- Portuguese
- Portuguese-utf8
- Brazilian-utf8
- Brazilian
- Polish
[/b][/color]
[hr]

[center][glow=black,2,300][color=green][size=15pt][b]Topic View Log[/b][/size][/color][/glow][/center]

[center][glow=black,2,300][color=green][size=13pt][b]Copyright 2011 | [url=http://www.smfsimple.com]SMFSimple.com[/url][/b][/size][/color][/glow][/center]

[center][url=http://creativecommons.org/licenses/by-nc-sa/3.0/][img]http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png[/img][/url][/center]