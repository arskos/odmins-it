[table]
[tr]
[td]
[color=#006400][size=16pt][b]Enhanced PM Popup 1.0.1[/b][/size][/color]
Replace the PM popup with a nice CSS Styled box.
[iurl=http://custom.simplemachines.org/mods/index.php?mod=2283]Link to Mod[/iurl] | [iurl=http://www.simplemachines.org/community/index.php?action=post;topic=349640]Comment On This Mod[/iurl]
[/td]
[td]
[b]Author:[/b] [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=11359]Spuds[/url]
[b]Type:[/b] [url=http://custom.simplemachines.org/mods/index.php?action=search;type=3]Theme Enhancements[/url]
[b]Available since:[/b] November 21 2009
[b]Latest version:[/b] 1.0.1 (June 27 2011)
[b]Compatible with:[/b] SMF 2.0
[b]Available languages:[/b] [size=1]
[img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/english_british.gif[/img] [img]http://www.simplemachines.org/site_images/lang/swedish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/french.gif[/img] [img]http://www.simplemachines.org/site_images/lang/romanian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_pt.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_brazilian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/italian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/arabic.gif[/img]
[/size]
[/td]
[/tr]
[/table]
[hr]

[color=#228B22][b][size=12pt]What does it do?[/size][/b][/color]
[i]Enhanced PM Popup[/i] will replace the alert box that popups on a new PM (If enabled through the profile) to a nicer box made with CSS and HTML. 
See screenshot for a preview.

[color=#228B22][b][size=12pt]How to use[/size][/b][/color]
To use [i]Enhanced PM Popup[/i], [url=http://custom.simplemachines.org/mods/index.php?mod=****]download the package from the SMF customization site[/url], and install it via your [url=http://docs.simplemachines.org/index.php?topic=95]Package Manger[/url].
All users who have enabled the PM popup through their profile will now see the new box when they recieve a new personal message.

[color=#228B22][b][size=12pt]Support & comments[/b][/color]
If you have a problem with this mod, want to comment, or have any question, please [url=http://www.simplemachines.org/community/index.php?action=post;topic=349640]post to the modification support topic[/url] and I will reply as soon as possible.

[color=#228B22][b][size=12pt]Other information[/size][/b][/color]
[b]Translation of this mod[/b]
o I am always happy to get translations of my work so that more users can use it. If you have translated this modification, please [url=http://www.simplemachines.org/community/index.php?action=post;topic=349640]post the translation in the support topic[/url]. 
Please make sure you have translated everything, and that there are no spelling misstakes etc.
Also, please post both a non-UTF8 version and a UTF8 version.

[hr]