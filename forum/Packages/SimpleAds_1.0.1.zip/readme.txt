[b]SimpleAds[/b]

This mod allows you to display HTML code in various locations of forum. You can limit ads by time, click, impressions, membergroups or actions. You can also create custom ad positions.

The mod requires minimal template edits. If you are using a custom theme, make sure you install the mod for those custom themes as well, using the "Install in Other Themes" option during the installation.

This mod uses [url=http://www.famfamfam.com/lab/icons/silk/]FamFamFam Silk[/url] icons licensed under Creative Commons Attribution 2.5 License.